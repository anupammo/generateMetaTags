<?php
function mtg_add_admin_menu() {
    add_options_page(
        'Meta Tag Generator Settings',
        'Meta Tag Generator',
        'manage_options',
        'meta-tag-generator',
        'mtg_settings_page'
    );
}
add_action('admin_menu', 'mtg_add_admin_menu');

function mtg_settings_page() {
    ?>
    <div class="wrap">
        <h1>Meta Tag Generator Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('mtg_settings_group');
            do_settings_sections('meta-tag-generator');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function mtg_register_settings() {
    register_setting('mtg_settings_group', 'mtg_default_og_type');
    register_setting('mtg_settings_group', 'mtg_default_twitter_card');
}
add_action('admin_init', 'mtg_register_settings');
?>
