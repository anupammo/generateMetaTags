=== Meta Tag Generator ===
Contributors: Anupam Mondal
Requires at least: 5.4
Tested up to: 6.0
License: GPL2

== Description ==
This plugin automatically fetches meta tags for WordPress pages/posts and allows users to edit them.

== Installation ==
1. Upload `meta-tag-generator.zip` to `/wp-content/plugins/`.
2. Activate the plugin in `Plugins` → `Installed Plugins`.
3. Open any post/page editor to see the Meta Tag Generator box.
4. Customize meta descriptions and save!

== Changelog ==
= 1.0.0 =
- Initial release.
